"""Finite exact checks and archival facts only. No universal-proof certification."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone,timedelta
import json,hashlib,sys,platform
R=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(i,ok,detail):
    checks.append({'id':i,'passed':bool(ok),'detail':detail})
def floor(q): return q.numerator//q.denominator
for d in [F(1,1000000),F(1,2),F(1),F(2),F(4),F(1000000)]:
    t=min(d/2,F(1,2));x=1-t
    check('endpoint_'+str(d),F(1,2)<=x<1 and 0<abs(x-1)<d and 1>=F(1,2),
          {'delta':str(d),'x':str(x),'distance':str(t),'limit_error':'1'})
check('old_witness_negative_control',1-F(4)/2<0,{'delta':'4','old_x':'-1','meaning':'Old formula fails; expected failure detected, not a valid witness.'})
for n in [1,2,3,10,100]:
    x=1-F(1,4*n);err=x**n
    check('nonuniform_rational_'+str(n),err>=F(3,4),{'n':n,'x':str(x),'error_exact':str(err),'comparison':'>=3/4'})
for x in [F(1,10),F(1,2),F(9,10)]:
    for eps in [F(1,2),F(1,10)]:
        t=1/x-1;N=floor(1/(t*eps))+1
        check('pointwise_tail_sample_'+str(x)+'_'+str(eps),x**N<eps,
              {'x':str(x),'epsilon':str(eps),'N':N,'sample_n':N,'note':'Only this sample computed; all n proof is D2.'})
def hat(n,x): return max(F(0),1-abs(2*n*x-1))
for n in [1,2,10,100]:
    pts=[F(0),F(1,2*n),F(1,n),F(1)]
    values=[hat(n,x) for x in pts]
    check('hat_boundaries_'+str(n),values==[F(0),F(1),F(0),F(0)],{'n':n,'points':list(map(str,pts)),'values':list(map(str,values))})
for x in [F(1,1000),F(1,10),F(1,2),F(1)]:
    N=floor(1/x)+1
    check('hat_tail_sample_'+str(x),hat(N,x)==0 and hat(N+1,x)==0,{'x':str(x),'N':N,'values_at_N_N1':['0','0']})
for n in [1,2,10]:
    check('x_over_n_control_'+str(n),max(F(k,10*n) for k in range(11))==F(1,n),
          {'n':n,'sample_grid_max':str(F(1,n)),'universal_bound':'For any x in [0,1], 0<=x/n<=1/n (D6).','note':'Grid does not prove supremum; analytic bound and endpoint do.'})
H=R/'evidence/inputs/output/theory-review-integration/public-case'
Q=R/'evidence/inputs/output/theory-quality-next'
raw=(H/'historical-output.txt').read_bytes()
payload=json.loads(raw.decode('utf-8-sig'))
oid=payload['proof_routes'][2]['obligations'][0]['id']
check('raw_id_length',len(oid)==49,{'id':oid,'length':len(oid),'contract_max':40,'meaning':'Confirm rejection fact, not repair.'})
check('public_raw_equal_live_raw',raw==(Q/'live/missing-condition/raw-model-content.txt').read_bytes(),{'sha256':sha(H/'historical-output.txt')})
check('raw_semantics_equal_archived_payload',payload==json.loads((Q/'live/missing-condition/model-payload.json').read_text(encoding='utf-8')),
      {'meaning':'Parsed JSON semantic comparison; byte equality asserted separately only for text.'})
messages=json.loads((Q/'inputs/missing-condition/messages.json').read_text(encoding='utf-8'))
text=next(m['content'] for m in messages if m['role']=='user')
context=json.loads(text[text.index('{'):])
check('original_input_only_counterexample_note',[n['note_id'] for n in context['evidence_notes']]==['quality-pointwise-note'],
      {'note_ids':[n['note_id'] for n in context['evidence_notes']],'later_uniform_note_present':False})
check('original_input_has_specific_feedback',bool(context.get('review_feedback')),
      {'feedback_count':len(context.get('review_feedback',[])),'scope':'Presence only; semantic evaluation is MODEL_COMPARISON.'})
cur=json.loads((H/'curated-proposal.json').read_text(encoding='utf-8'))
ids=[o['id'] for route in cur['proof_routes'] for o in route['obligations']]
check('four_original_obligation_ids',set(ids)=={'pointwise_limit','witness_domain','uniform_quantifiers','relative_continuity'}, {'ids':ids})
out=R/'calculations';out.mkdir(exist_ok=True)
report={'executed_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),'python':sys.version,'platform':platform.platform(),
        'script_sha256':sha(Path(__file__)),'origin':'actual_local_standard_library_execution',
        'arithmetic':'fractions.Fraction, exact rational for listed finite inputs',
        'scope':'Finite samples, negative controls and archival facts; not a proof of universal mathematical statements, not Lean or app tests.',
        'checks':checks,'check_count':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
        'universal_proof_certified':False,'independent_mathematician_review':'pending',
        'model_requests':0,'database_access':False,'website_requests':0,'lean_runs':0}
(out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['executed_at','check_count','passed','failed','universal_proof_certified']},ensure_ascii=False))
raise SystemExit(1 if report['failed'] else 0)
