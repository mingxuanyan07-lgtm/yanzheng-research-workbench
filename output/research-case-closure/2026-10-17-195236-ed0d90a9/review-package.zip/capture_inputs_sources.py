"""One-shot archival capture. Writes only beside this script; no app imports/config/DB."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, json, shutil, urllib.request
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
def sha(b): return hashlib.sha256(b).hexdigest()
def now(): return datetime.now(timezone(timedelta(hours=8))).isoformat()
def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

paths = ['README.md','docs/ROADMAP.md','docs/理论论证工作流.md',
 'output/theory-quality-next/README.md','output/theory-quality-next/READY.json',
 'output/theory-quality-next/validation.json',
 'output/theory-quality-next/offline/math-reference-review.md',
 'output/theory-review-integration/README.md','output/theory-review-integration/api-contract.md',
 'output/acceptance-supervisor-2026-10-17-193613/validation.json',
 'output/theory-quality-next/reviewed/missing-condition/feedback.json',
 'output/theory-quality-next/live/missing-condition/raw-model-content.txt',
 'output/theory-quality-next/live/missing-condition/model-payload.json',
 'output/theory-quality-next/inputs/missing-condition/input-project.json',
 'output/theory-quality-next/inputs/missing-condition/messages.json']
paths += [p.relative_to(PROJECT).as_posix() for p in sorted((PROJECT/'output/theory-review-integration/public-case').iterdir()) if p.is_file()]
if (ROOT/'INPUT_MANIFEST.json').exists(): raise SystemExit('Refuse overwriting captured inputs')
entries=[]
for rel in paths:
    src=PROJECT/rel
    dst=ROOT/'evidence/inputs'/rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    data=src.read_bytes()
    dst.write_bytes(data)
    entries.append({'source_path':str(src), 'copy_path':dst.relative_to(ROOT).as_posix(),
                    'sha256':sha(data),'bytes':len(data),'captured_at':now(),
                    'origin':'historical_artifact_verbatim_copy','independent_human_review':False})
write_json(ROOT/'INPUT_MANIFEST.json', {'hash_scope':'exact file bytes; copies do not certify original authorship', 'files':entries})
monitor=['webapp/theory.py','webapp/theory_examples.py','webapp/app.py','webapp/model_service.py',
         'webapp/static/app.js','webapp/static/index.html','webapp/static/styles.css','webapp/static/lean-ui.js',
         'webapp/lean_api.py','webapp/lean_service.py','webapp/lean_worker.py']
write_json(ROOT/'PROTECTED_BASELINE.json',{'scope':'Selected source hashes only; never imports application or reads config/database. Not a whole-workspace snapshot.',
 'captured_at':now(),'files':[{'path':str(PROJECT/p),'sha256':sha((PROJECT/p).read_bytes())} for p in monitor if (PROJECT/p).is_file()]})

class Text(HTMLParser):
    def __init__(self): super().__init__(); self.out=[]; self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'): self.skip+=1
        if not self.skip and tag in ('p','div','section','h1','h2','h3','h4','li','br','article'): self.out.append('\n')
    def handle_endtag(self,tag):
        if tag in ('script','style') and self.skip: self.skip-=1
        if not self.skip and tag in ('p','div','section','h1','h2','h3','h4','li','article'): self.out.append('\n')
    def handle_data(self,data):
        if not self.skip: self.out.append(data)

out=ROOT/'sources';out.mkdir(exist_ok=True)
retrieval=[]
for sid,url in [('UW521','https://people.math.wisc.edu/~angenent/521.2017s/UniformConvergence.html'),
                ('LEBL62','https://www.jirka.org/ra/html/sec_liminter.html')]:
    rec={'source_id':sid,'requested_url':url,'requested_at':now(),'method':'public HTTPS GET via urllib; no credentials',
         'reading_status':'downloaded_not_automatically_read'}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'ResearchCaseVerification/1.0','Accept-Encoding':'identity'})
        with urllib.request.urlopen(req,timeout=25) as r:
            data=r.read(2000001)
            if len(data)>2000000: raise ValueError('body size limit exceeded')
            rec.update({'http_status':r.status,'final_url':r.geturl(),'headers':{k:r.headers.get(k) for k in ['Content-Type','Last-Modified','ETag','Date']},
                        'encoding':r.headers.get_content_charset() or 'utf-8'})
        (out/(sid+'.html')).write_bytes(data)
        rec.update({'body_path':'sources/'+sid+'.html','body_sha256':sha(data),'bytes':len(data),'hash_scope':'HTTP entity bytes returned by urllib, not TLS wire bytes'})
        parser=Text();parser.feed(data.decode(rec['encoding'],errors='strict'))
        lines=[' '.join(line.split()) for line in ''.join(parser.out).splitlines() if line.strip()]
        txt='\n'.join(f'{i:04d}: {line}' for i,line in enumerate(lines,1))+'\n'
        (out/(sid+'.text.txt')).write_text(txt,encoding='utf-8')
        rec.update({'text_path':'sources/'+sid+'.text.txt','text_sha256':sha((out/(sid+'.text.txt')).read_bytes()),'status':'retrieved',
                    'text_hash_scope':'actual saved extraction file bytes (platform newlines included)'})
    except Exception as e:
        rec.update({'status':'unverified_access_failed','error_type':type(e).__name__,'error':str(e)[:500]})
    rec['completed_at']=now();retrieval.append(rec)
write_json(out/'retrieval.json',{'sources':retrieval,'scope':'Fetch facts only; actual inspected ranges recorded separately.'})
print(json.dumps({'input_copies':len(entries),'source_retrievals':retrieval},ensure_ascii=False,indent=2))
