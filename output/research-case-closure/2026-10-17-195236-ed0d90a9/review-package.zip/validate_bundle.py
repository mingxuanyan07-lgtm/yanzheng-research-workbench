"""Read-only input/record validation, plus writes reports only to this run directory."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name): return json.loads((R/name).read_text(encoding='utf-8-sig'))
checks=[]
def check(i,ok,detail=None): checks.append({'id':i,'passed':bool(ok),'detail':detail})
required=['CASE_SPEC.md','SOURCE_VERIFICATION.md','SOURCE_VERIFICATION.json','claim-ledger.json','claim-ledger.md',
          'DERIVATION.md','MODEL_COMPARISON.md','OBLIGATIONS.md','OBLIGATIONS.json','ISSUES.md','HANDOFF.md',
          'ACCEPTANCE_SCENARIOS.md','FORMAL_SEMANTICS_REQUIREMENTS.md','review-package/README.md',
          'review-package/QUESTIONS.md','review-package/REVIEW_FORM.json','README.md','INPUT_MANIFEST.json',
          'PROTECTED_BASELINE.json','CODE_OBSERVATIONS.json','EXECUTION_LOG.md','calculations/results.json']
check('required_content_files',all((R/p).is_file() for p in required),{'missing':[p for p in required if not (R/p).is_file()]})
inputs=read('INPUT_MANIFEST.json')['files']
copy_mismatch=[];original_mismatch=[]
for item in inputs:
    if sha(R/item['copy_path'])!=item['sha256']:copy_mismatch.append(item['copy_path'])
    if sha(Path(item['source_path']))!=item['sha256']:original_mismatch.append(item['source_path'])
check('23_input_copies_preserved',len(inputs)==23 and not copy_mismatch,{'count':len(inputs),'mismatches':copy_mismatch})
check('input_originals_unchanged_since_capture',not original_mismatch,{'mismatches':original_mismatch,'scope':'Only listed 23 originals, no database or whole-workspace claim.'})
baseline=read('PROTECTED_BASELINE.json')['files'];drift=[]
for item in baseline:
    current=sha(Path(item['path']))
    if current!=item['sha256']:drift.append({'path':item['path'],'baseline_sha256':item['sha256'],'observed_sha256':current})
check('selected_production_hashes_unchanged',not drift,{'count':len(baseline),'changes':drift,'scope':'11 selected files, not entire repository.'})
checks[-1]['severity']='warning' if drift else 'info'
checks[-1]['blocking_for_material_delivery']=False
(R/'SOURCE_DRIFT.json').write_text(json.dumps({'observed_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
 'origin':'actual_read_only_before_after_hash_comparison','changes':drift,
 'meaning':'Concurrent changes observed; no source edits by this task; not a frozen application acceptance.',
 'i01_status':'historical_defect_candidate_source_change_observed_dynamic_verification_pending',
 'initial_failed_validation_preserved':'validation/attempt-01.json'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
arch=read('evidence/inputs/output/theory-quality-next/READY.json')
base='evidence/inputs/output/theory-quality-next/'
old=[];old_checked=0
for item in inputs:
    p=item['copy_path']
    if p.startswith(base):
        rel=p[len(base):];expected=arch.get('artifact_sha256',{}).get(rel)
        if expected:
            old_checked+=1
            if expected!=item['sha256']:old.append(rel)
check('available_v14_ready_hashes_match',not old,{'checked':old_checked,'mismatches':old,'scope':'Only copied inputs listed in historical READY.'})
sources=read('SOURCE_VERIFICATION.json')['sources'];source_bad=[]
for s in sources:
    a=s['snapshot']
    if sha(R/a['body_path'])!=a['body_sha256'] or sha(R/a['text_path'])!=a['text_sha256']:source_bad.append(s['id'])
check('source_snapshot_byte_hashes',not source_bad and len(sources)==2,{'source_count':len(sources),'mismatches':source_bad})
ledger=read('claim-ledger.json')['claims'];ids={c['id'] for c in ledger};bad=[]
for c in ledger:
    for key in ['claim','proposition_version','evidence','derivation','counterexample_check','applicable_conditions','verification_status','unresolved_questions']:
        if not c.get(key):bad.append(c['id']+':'+key)
    for e in c['evidence']:
        p=(R/e['path']).resolve()
        if not p.is_relative_to(R) or not p.is_file() or sha(p)!=e['sha256']:bad.append(c['id']+':reference:'+e['path'])
    if any(d not in ids for d in c['depends_on']):bad.append(c['id']+':dependency')
check('18_claims_have_required_fields_and_exact_evidence',len(ledger)==18 and len(ids)==18 and not bad,{'problems':bad})
graph={c['id']:c['depends_on'] for c in ledger}
done=set();visiting=set()
def visit(i):
    if i in visiting:return False
    if i in done:return True
    visiting.add(i)
    if not all(visit(d) for d in graph[i]):return False
    visiting.remove(i);done.add(i);return True
check('claim_dependencies_acyclic',all(visit(i) for i in graph))
obls=read('OBLIGATIONS.json')['obligations']
expected={'pointwise_limit','witness_domain','uniform_quantifiers','relative_continuity'}
check('four_obligations_preserve_statuses',len(obls)==4 and {o['id'] for o in obls}==expected and all(
 o['application_status']=='open' and o['formal_status']=='not_formally_verified' and o['independent_mathematician_review']=='pending' and
 o['independent_reviewer'] is None and o['independent_review_conclusion'] is None and all(c in ids for c in o['claim_ids']) and
 sha(R/o['material']['path'])==o['material']['sha256'] for o in obls))
form=read('review-package/REVIEW_FORM.json')
check('independent_review_form_blank',form['status']=='pending' and form['independent_reviewer'] is None and form['reviewed_at'] is None and
 form['overall_conclusion'] is None and not form['actually_read_materials'] and all(o['conclusion'] is None for o in form['obligations']))
calc=read('calculations/results.json')
check('finite_checks_actually_completed',calc['failed']==0 and calc['passed']==35 and calc['check_count']==35 and calc['universal_proof_certified'] is False and
 calc['script_sha256']==sha(R/'offline_checks.py'),{'result_file':'calculations/results.json','sha256':sha(R/'calculations/results.json')})
code=read('CODE_OBSERVATIONS.json')
check('source_observation_snapshot',sha(R/code['snapshot_path'])==code['sha256'])
v=R/'validation';v.mkdir(exist_ok=True)
validator=Path('C:/Users/HUAWEI/.codex/skills/literature-search/scripts/validate_literature_record.py')
run=subprocess.run([sys.executable,'-B','-X','utf8',str(validator),str(R/'SOURCE_VERIFICATION.json')],capture_output=True,text=True,encoding='utf-8')
(v/'literature-contract.txt').write_text(run.stdout+run.stderr,encoding='utf-8')
check('literature_schema_validator',run.returncode==0,{'exit_code':run.returncode,'validator_path':str(validator),'validator_sha256':sha(validator),
 'log':'validation/literature-contract.txt','log_sha256':sha(v/'literature-contract.txt'),'meaning':'Structure and provenance consistency only, not mathematical truth.'})
json_bad=[];json_count=0
for p in R.rglob('*.json'):
    if p.name=='validation.json' and p.parent==R:continue
    try:json.loads(p.read_text(encoding='utf-8-sig'));json_count+=1
    except Exception as e:json_bad.append({'path':p.relative_to(R).as_posix(),'error_type':type(e).__name__})
check('all_saved_json_parse',not json_bad,{'count':json_count,'problems':json_bad})
blocking_failed=[c for c in checks if not c['passed'] and c.get('severity')!='warning']
warnings=[c for c in checks if not c['passed'] and c.get('severity')=='warning']
report={'schema_version':'research-case-delivery-validation-v1','checked_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
 'status':('material_check_failure' if blocking_failed else 'materials_ready_with_source_drift_independent_review_pending' if warnings else 'materials_ready_independent_review_pending'),
 'checks':checks,'check_count':len(checks),'passed':sum(c['passed'] for c in checks),'warnings':len(warnings),'failed':len(blocking_failed),
 'mathematical_proof_draft':'complete','assistant_math_review':'complete','independent_mathematician_review':'pending',
 'formal_verification':'not_executed','application_obligations':'open_unchanged','case_final_acceptance':False,
 'new_model_quality_evidence':False,'historical_v14_raw_outputs':'all_three_rejected_as_returned',
 'execution_scope':{'real_model_calls':0,'website_api_calls':0,'website_started':False,'lean_runs':0,'database_access':False,
                    'credential_access':False,'production_source_edits':0,'old_archive_edits':0,'outbound_messages':0,
                    'public_sources_retrieved':2,'finite_exact_and_archival_checks':35},
 'not_performed':['browser_acceptance','joint_full_regression','independent_human_mathematician_review','formal_semantic_verification'],
 'process_diagnostics':'EXECUTION_LOG.md; earlier read-only JSON prefix parse error and extraction newline hash correction retained.',
 'limitations':['Hashes are byte integrity, not mathematical certification.','Protected hashes cover named files only.','A/B runtime and interaction scenarios remain handoff, not executed here.']}
(R/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['checked_at','status','check_count','passed','warnings','failed','case_final_acceptance']},ensure_ascii=False))
if report['failed']:
    print(json.dumps([c for c in checks if not c['passed']],ensure_ascii=False,indent=2))
raise SystemExit(1 if report['failed'] else 0)
