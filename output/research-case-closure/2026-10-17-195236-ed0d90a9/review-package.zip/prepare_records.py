"""Build explicit evidence records from reviewed material; does not run the app."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, json
R=Path(__file__).resolve().parent
P=R.parents[2]
T=datetime.now(timezone(timedelta(hours=8))).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,obj):
    (R/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ref(path,locator,boundary):
    return {'path':path,'sha256':sha(R/path),'locator':locator,'support_boundary':boundary}
H='evidence/inputs/output/theory-review-integration/public-case/'
Q='evidence/inputs/output/theory-quality-next/'
retr=json.loads((R/'sources/retrieval.json').read_text(encoding='utf-8'))['sources']
source_specs=[
 ('UW521','Math 521 — Uniform Convergence',['UW–Madison Math 521 course notes'],
  '2017 spring course URL; no confirmed scholarly revision; HTTP Last-Modified 2019-10-21; under construction',
  'Pointwise definition; x^n example; Uniform convergence definition and nonuniformity argument; Three consequences first theorem',
  [[5,8],[15,20],[54,80],[150,154]],
  '反例限制P0；定义与定理陈述核对P1。精确端点见证和ε–δ细节不是该处原文证明。'),
 ('LEBL62','Basic Analysis — §6.2 Interchange of limits',['Jiří Lebl'],
  'Current HTML snapshot; print edition/revision unconfirmed; HTTP Last-Modified 2026-05-23',
  '§6.2.1; Example 6.2.1; Theorem 6.2.2 and proof; Exercises 6.2.5, 6.2.10, 6.2.11 statements only',
  [[424,519],[870,874],[913,923]],
  '定理与序列式证明核对P1；习题题面不认证本稿峰列公式或Dini完整证明。')]
sources=[];logs=[]
for (sid,title,authors,version,locator,ranges,bound), raw in zip(source_specs,retr):
    assert sid==raw['source_id'] and raw['status']=='retrieved'
    search_id='direct_'+sid
    logs.append({'id':search_id,'provider':'public_html_direct_lookup','query':raw['requested_url'],
      'status':'success','searched_at':raw['requested_at'],'attempts':1,'result_count':1,'error':None,
      'scope':'One direct urllib public HTML request; web-tool open/find used separately for navigation, not keyword search.'})
    sources.append({'id':sid,'title':title,'authors':authors,'year_or_version':version,'url':raw['final_url'],
      'origin':'prior_project','verification':'fulltext_checked','locator':locator,'checked_at':T,
      'identifiers':{'doi':None,'arxiv_id':None,'openalex_id':None},'abstract':None,
      'access':{'is_open_access':True,'landing_page_url':raw['final_url'],'pdf_url':None,'license':None},
      'retrievals':[{'search_id':search_id,'provider':'public_html_direct_lookup','url':raw['requested_url'],'retrieved_at':raw['completed_at']}],
      'snapshot':raw,'actual_read_ranges':{'file':raw['text_path'],'numbered_lines_inclusive':ranges,'printed_pages':None},
      'support_boundary':bound,'not_read':'Other sections not listed; no book-wide reading claim',
      'reader_type':'assistant','independent_mathematician_review':'pending',
      'historical_model_input_changed':False})
put('SOURCE_VERIFICATION.json',{
 'schema_version':'1.0','record_type':'research_literature_search','created_at':T,
 'request':{'idea':'复核既有[0,1]点态反例、一致收敛充分修订及条件边界；直接核对种子正文。',
            'queries':[s['requested_url'] for s in retr],'providers':['public_html_direct_lookup'],
            'year_from':None,'year_to':None,'max_results_per_query':1},
 'provenance':{'generator':'assistant_source_review_with_saved_public_html','live_search_performed':True,
               'external_model_api_called':False,'new_experiments_executed':False,
               'search_kind':'direct_seed_lookup_not_keyword_search','reader':'assistant'},
 'search_log':logs,'sources':sources,
 'evidence':[{'source_id':'UW521','relation':'limits','claim':'[0,1]上x^n的点态极限反驳P0。','locator':'The problems with pointwise convergence, x^n; saved text 15–20'},
             {'source_id':'UW521','relation':'supports','claim':'一致收敛定义与连续极限充分定理陈述。','locator':'saved text 54–58,150–154'},
             {'source_id':'LEBL62','relation':'supports','claim':'一致极限定理及以固定函数指标控制两个误差项的序列式证明。','locator':'Theorem 6.2.2 and proof; saved text 483–516'},
             {'source_id':'LEBL62','relation':'background','claim':'习题6.2.5提示闭区间非一致且连续极限的问题；6.2.10–11只读题面。','locator':'Exercises 6.2.5,6.2.10,6.2.11'}],
 'limitations':['仅相关正文，未通读教材；网页无确认印刷版次；Last-Modified不是出版日期。',
                '两条种子直接核对，不是广泛查新；新来源不回填原模型输入。',
                '历史Lebl §11.6/§11.7本轮未重新核对；不承担主证明。',
                '有限离线计算另记calculations/results.json，不计入文献检索实验事实。'],
 'unverified_historical_references':[{'url':'https://www.jirka.org/ra/html/sec_arzelaascoli.html','status':'not_rechecked_this_round'},
                                     {'url':'https://www.jirka.org/ra/html/sec_stoneweier.html','status':'not_rechecked_this_round'}],
 'next_action':'独立数学工作者按review-package问题清单核对来源范围及主稿。'})

uw=lambda loc,b:ref('sources/UW521.html',loc,b)
lb=lambda loc,b:ref('sources/LEBL62.html',loc,b)
der=lambda sec:ref('DERIVATION.md',sec,'本轮助手推导；非原模型输出、非独立人工或形式核验。')
claims=[]
def add(cid,version,claim,evidence,derivation,counterexample,conditions,deps=(),status='assistant_checked_proof_draft_complete',obligations=()):
    claims.append({'id':cid,'claim':claim,'proposition_version':version,'evidence':evidence,
      'derivation':derivation,'counterexample_check':counterexample,'applicable_conditions':conditions,
      'depends_on':list(deps),'obligation_ids':list(obligations),'verification_status':status,
      'unresolved_questions':['独立数学工作者尚未审阅本条的推理、范围与归因。'],
      'actor':'assistant','independent_mathematician_review':'pending','formal_status':'not_formally_verified'})
add('C01','P0','每个正整数n，x^n在[0,1]上相对连续。',[der('D1'),uw('x^n example; text15–20','来源反例背景；具体n-Lipschitz估计由助手给出。')],
 '因式分解得|x^n-a^n|≤n|x-a|；δ=η/n。','检查n=1与a=0,1；δ依赖n合法。','n≥1；a,x∈[0,1]；η>0',obligations=['pointwise_limit'])
add('C02','P0','点态极限是x<1时0、x=1时1。',[der('D2'),uw('x^n example; text15–20','直接记载分段极限；显式N为助手展开。')],
 '端点直接；0<x<1令t=1/x-1，Bernoulli和N>1/(tε)给全尾误差。','不能把N(x,ε)当全域共同N。','∀x∈D ∀ε>0 ∃N≥1 ∀n≥N',deps=['C01'],obligations=['pointwise_limit'])
add('C03','P0','f在1不连续，x=1-min(δ/2,1/2)对全δ合法。',[der('D3'),ref(H+'curated-proposal.json','proof_routes[1].steps[1]','历史人工精确见证，待本轮推导核查。')],
 'ε₀=1/2；0<t≤1/2且t≤δ/2<δ；x∈[1/2,1)，函数差1。','旧x=1-δ/2在δ=4时出域；不借右侧函数值。','∀δ>0；相对域D',deps=['C02'],obligations=['witness_domain'])
add('C04','P0','P0普遍命题为假。',[der('D1–D3')],
 '同一列满足每项连续与逐点收敛而极限不连续。','反例覆盖全部前提，不能只说经典反例。','P0的域、值域、n量词完全不变',deps=['C01','C02','C03'],obligations=['pointwise_limit','witness_domain'])
add('C05','P0','x^n到该分段极限不一致收敛。',[der('D4'),uw('nonuniformity; text59–80','来源用根式见证；本稿有理见证不是摘录。')],
 'ε₀=1/2；给N取n=N,x=1-1/(4n)；Bernoulli下界3/4。','峰值靠端点，固定网格不能证明或排除。','∀N≥1 ∃n≥N ∃x∈D',deps=['C02'])
add('C06','P1','一致收敛量词中N不依赖自变量。',[der('D0,D5.1'),uw('Uniform convergence definition; text54–58','直接支持定义。')],
 '∀ε>0 ∃N ∀n≥N ∀y∈D。','交换∀y与∃N得到点态收敛，C01–C05说明不够。','同一个域D，同一极限函数',obligations=['uniform_quantifiers'])
add('C07','P1','同一个f_N同时控制x和a两个逼近误差。',[der('D5.1'),lb('Theorem6.2.2 proof; text490–494','来源函数指标名k；本稿名N。')],
 '对ε/3选统一N再特取n=N；分别代y=x和y=a。','不得用N(x)和N(a)却不解释统一选择；无需先知道x。','一致收敛；x,a∈D',deps=['C06'],obligations=['uniform_quantifiers'])
add('C08','P1','固定f_N后由其在a的相对连续性选δ。',[der('D5.2'),lb('Theorem6.2.2 and proof; text483–516','原文序列连续性；ε–δ展开属本稿。')],
 '容差ε/3；δ依赖a、ε、固定N，随后对全部邻域内x有效。','不要求δ对所有n有效；两端点只取域内x。','每项相对连续；N已经固定',deps=['C07'],obligations=['relative_continuity'])
add('C09','P1','三角不等式给|f(x)-f(a)|<ε。',[der('D5.3')],
 '两个统一逼近误差加固定函数连续性误差，三项各<ε/3。','没有把≤ε误当<ε；直接用逐点共同界避开严格sup陷阱。','|x-a|<δ且x∈D',deps=['C07','C08'],obligations=['relative_continuity'])
add('C10','P1','一致收敛保持连续性是充分修订；此推导不需紧致性。',[der('D5'),uw('first continuity theorem; text150–154','一般度量定义域陈述，不要求紧致。'),lb('Theorem6.2.2; text483–484','任意实数子集陈述。')],
 'a与ε任意，连续性定义成立；逐步未使用有限覆盖。','不能将“P1真”标为“P0真”；不反推必要性。','每项连续+同域一致收敛',deps=['C09'],obligations=['relative_continuity'])
add('C11','P2','h_n=max(0,1-|2nx-1|)每项在D连续。',[der('D6'),ref(Q+'offline/math-reference-review.md','missing-condition辅助例','历史助手例子；本轮展开，不是模型给出。')],
 '分段接点一致或2n-Lipschitz。','x=0、1/(2n)、1/n、1全包含；n=1合法。','n≥1，D=[0,1]')
add('C12','P2','h_n在D上逐点至恒零连续函数。',[der('D6')],
 'x=0恒零；x>0取N>1/x，尾项全零。','移动点x_n不固定，不能用其值1否定点态收敛。','先固定x；N可依赖x',deps=['C11'])
add('C13','P2','h_n不一致收敛；因此一致收敛非必要。',[der('D6'),lb('Exercise6.2.5 and note; text870–874','只有任务题面；不作为此精确构造已证依据。')],
 '给N取n=N，x_n=1/(2n)，误差1；与C11–C12合并。','ε₀=1/2固定，所有N均有峰顶。','与P1相同定义域及连续函数列',deps=['C11','C12'])
add('C14','P2','x/n在D上一致至零，不能作为非一致反例。',[der('D6'),ref(H+'original-context.json','theory.proposals[0].submitted_payload.search_leads[0]','记录错误候选的原位置，不给数学背书。')],
 '全域误差≤1/n且x=1达到；取N>1/ε。','不是将x/n改完后记作旧模型正确。','D=[0,1]，n≥1')
add('C15','H14','原唯一反例笔记不足以归因修补定理。',[ref(Q+'inputs/missing-condition/messages.json','user.evidence_notes[0] / review_feedback[0]','实际冻结输入，用户内容在引导句后。'),ref(H+'historical-output.txt','proof_routes[0].evidence[0].claim','原始越界语句。')],
 '逐字对比笔记内容与claim；同URL其他段落并未进入该笔记。','background标签与后来新读正文均不能追溯扩大原范围。','仅谈历史输入支持范围，不否认P1真',status='assistant_checked_evidence_scope_failure')
add('C16','H14','超长义务ID有49字符，原结构拒绝应保留。',[ref(H+'historical-output.txt','proof_routes[2].obligations[0].id','原字符串。'),ref(Q+'inputs/missing-condition/messages.json','system ID max40 contract','历史合同。')],
 '标准库len和ASCII合同检查，原字节不变。','结构错误不推出数学命题为假。','原v1.4输出',status='assistant_checked_archival_fact')
add('C17','HISTORICAL','v1.4三份原样输出均整体拒绝；本轮无新模型改善证据。',[ref(Q+'validation.json','overall_status / cases[*].overall_usable_as_returned','历史报告，不是本轮重试或重评全部三案。')],
 '保留历史状态；本轮禁止新增请求。','主案正确片段/人工稿不计为模型整体成功。','历史三案结论与本轮执行事实分开',status='historical_report_checked')
add('C18','REVIEW_STATUS','四应用义务仍open；独立审阅pending；无形式证明。',[ref(H+'README.md','人工版与四项义务说明','历史应用状态依据，非当前DB读取。'),ref(H+'claim-ledger.json','independent_mathematician_review','旧助手记录仍待真人。')],
 '本轮只交外部材料，不写应用状态。','助手自查、有限计算和旧independent文件名均不构成人工专家认证。','本轮及已提供历史材料',status='status_boundary_preserved')
put('claim-ledger.json',{'schema_version':'research-case-claim-ledger-v1','created_at':T,'author_type':'assistant',
 'scope':'已知结果复核与条件分析','independent_mathematician_review':'pending','claims':claims})
lines=['# 逐条论断账本','', '身份：助手核查。机器原件为 claim-ledger.json；每项依据含具体位置与文件 SHA256；本文件哈希见 ARTIFACT_MANIFEST。独立审阅统一 pending。','']
for c in claims:
    lines += [f"## {c['id']} · {c['proposition_version']}", '',c['claim'],'',
              f"- 推导：{c['derivation']}",f"- 反例/边界检查：{c['counterexample_check']}",
              f"- 条件：{c['applicable_conditions']}",f"- 核查状态：{c['verification_status']}；未决：{c['unresolved_questions'][0]}",
              f"- 依赖：{', '.join(c['depends_on']) or '无'}；原义务：{', '.join(c['obligation_ids']) or '不新增义务'}"]
    for e in c['evidence']:
        lines += [f"- 依据：`{e['path']}`；位置：{e['locator']}；边界：{e['support_boundary']}；SHA256 `{e['sha256']}`"]
    lines += ['']
(R/'claim-ledger.md').write_text('\n'.join(lines),encoding='utf-8')
obls=[('pointwise_limit',[],['C01','C02'],'D1,D2'),
      ('witness_domain',['pointwise_limit'],['C03','C04'],'D3'),
      ('uniform_quantifiers',[],['C06','C07'],'D0,D5.1'),
      ('relative_continuity',['uniform_quantifiers'],['C08','C09','C10'],'D5.2,D5.3')]
put('OBLIGATIONS.json',{'schema_version':'external-obligation-review-v1','created_at':T,'not_an_application_update':True,
 'obligations':[{'id':i,'depends_on':d,'claim_ids':cs,'material':ref('DERIVATION.md',sec,'完整助手推导，待独立审阅'),
                 'proof_draft':'complete','assistant_check':'complete','application_status':'open',
                 'formal_status':'not_formally_verified','independent_mathematician_review':'pending',
                 'independent_reviewer':None,'independent_review_date':None,'independent_review_conclusion':None}
                 for i,d,cs,sec in obls]})
# Snapshot only source already read, never import it or inspect config/storage.
dst=R/'evidence/theory.py.snapshot.txt'
if not dst.exists(): dst.write_bytes((P/'webapp/theory.py').read_bytes())
put('CODE_OBSERVATIONS.json',{'observed_at':T,'source_path':str(P/'webapp/theory.py'),
 'snapshot_path':'evidence/theory.py.snapshot.txt','sha256':sha(dst),'execution':'read_only_text_no_import',
 'initial_observation':{'finding':'Earlier read showed legacy filtering by card_version, matching supervisor evidence.',
                        'full_source_bytes_saved_at_initial_read':False,'location_in_earlier_version':'_review_feedback line327 onward',
                        'not_the_saved_snapshot':'The snapshot captured at20:02 already contains concurrent changes.'},
 'locations':[{'lines':[215,244],'finding':'New snapshot has unified feedback_exclusion with stored basis and stale-context checks; not executed.'},
              {'lines':[365,419],'finding':'_feedback_selection handles all three kinds and returns dispositions; candidate change, runtime unverified.'},
              {'lines':[159,169],'finding':'Snapshot hashes content/note/source metadata, not fetched page entity bytes.'},
              {'lines':[557,596],'finding':'Obligations carry open status; evidence relation unverified; no per-claim review contract.'}]})
print(json.dumps({'claims':len(claims),'sources':len(sources),'obligations':len(obls),'created_at':T},ensure_ascii=False))
