# 研究案例闭环交付：已知结果复核与条件分析

日期：2026-10-17，Asia/Shanghai。轮次：2026-10-17-195236-ed0d90a9。**证明稿及助手核查材料完成，独立数学工作者审阅 pending；未作最终案例验收。**

数学结论：P0“连续函数列逐点收敛保证极限连续”为假，xⁿ在[0,1]给出完整反例；P1加强为一致收敛后，ε/3证明成立；同域移动三角峰说明一致收敛不是必要条件。此为经典结果复核，不是新定理。

原件保留：v1.4三份真实原样输出仍全部拒绝，主案原文与历史live文本按字节相同。本轮没有新模型调用或模型质量改善证据。人工整理、本轮助手推导、实际有限计算和未来独立审阅分别记录。应用四义务保持open，形式状态保持not_formally_verified；本轮未访问应用数据库。

## 阅读入口

| 文件 | 内容与身份 |
|---|---|
| CASE_SPEC.md | P0/P1/P2、域与量词、资料范围、成功标准及排除结论；助手规格 |
| SOURCE_VERIFICATION.md / .json | 两条公开来源的实际正文核查、版本限制、定位与支持范围；助手阅读 |
| claim-ledger.md / .json | 18条论断逐一对应版本、证据位置/哈希、推导、反例、条件、状态和未决项 |
| DERIVATION.md | 全量词反例、同一个N、相对连续性ε/3及非必要性完整推导；助手稿 |
| MODEL_COMPARISON.md | 17项原模型/反馈/人工修订对照；正确、错误、越界和未复核旁支分别标明 |
| OBLIGATIONS.md / .json | 四义务的外部检查材料、结论依据、open/pending状态边界 |
| ISSUES.md / ACCEPTANCE_SCENARIOS.md | I01–I09实际缺陷/能力缺口/待验收项及B01–B07、A01–A02可执行场景 |
| HANDOFF.md | 只通过新交付给A/B/总验收的需求；未发送消息 |
| FORMAL_SEMANTICS_REQUIREMENTS.md | 将来形式化的语义对应要求，未运行Lean |
| review-package/ | 独立数学工作者阅读路线、10项问题、空白审阅表；未联系任何人 |
| review-package.zip | 本轮完整便携审阅包，含原件副本、来源快照、推导及冻结记录 |
| evidence/inputs/ | 23个历史输入原字节副本；保留旧措辞不代表本轮认可 |
| sources/ | 2份HTML实体快照、带行号提取文本和实际HTTP获取元数据 |
| calculations/results.json | 实际35项标准库精确分数/负向对照/归档检查；不证明普遍命题 |
| validation.json / validation/ | 本轮结构、关联、完整性与范围校验及真实输出 |
| EXECUTION_LOG.md | 实际执行范围、两项本地过程问题及修正，不隐去诊断 |

## 原件与哈希规则

INPUT_MANIFEST记录历史每份原件的原路径、副本路径、字节数、获取时间和SHA256。SOURCE_VERIFICATION及sources/retrieval记录当前公开正文快照及支持范围。CODE_OBSERVATIONS与只读源码快照为产品缺陷定位材料。ARTIFACT_MANIFEST逐文件记录新产物/原件/来源/计算的身份、来源链和字节SHA256。

READY记录ARTIFACT_MANIFEST哈希与待办；review-package.zip包含实质文件、ARTIFACT_MANIFEST与READY。最外层SHA256SUMS覆盖所有交付文件（包括READY、manifest、ZIP），只排除它自身以避免自引用。SHA256确认字节一致性，不认证作者身份、数学真值或独立审阅；ZIP内无需包含ZIP本身或封包后生成的最外层校验清单。

## 离线复核

数学审阅不需要执行脚本。若需要本地复算，在**本轮目录**使用已有Python运行 `python -B -X utf8 offline_checks.py`；会更新本轮calculations/results.json的时间，不应将复算的新字节冒充冻结原件。建议先复制整个包后复算。该脚本仅用标准库，不导入项目应用、不读配置/数据库、不联网。

`validate_bundle.py`检查记录和输入/产物关系；其结果是结构/完整性检查，不是数学正确性认证。`capture_inputs_sources.py`为已执行的抓取脚本，拒绝覆盖已有INPUT_MANIFEST，不需要重新联网运行。`prepare_records.py`与`finalize_delivery.py`是本轮记录生成/封包脚本；归档后不要在原冻结目录重跑。

## 剩余事项

独立数学工作者审阅四义务、必要性边界和证据归因尚未发生。B需处理旧反馈上下文适用性，完成整份浏览器下载和前端合同验收，并评估逐论断/逐义务材料关联；A需处理历史Lean运行问题。任何本案形式核验先审阅语义映射，不能用固定加零替代。总验收根据实际后续证据判断最终案例状态。

本轮发现A/B生产文件并行变化；新theory.py已出现统一反馈过滤候选改动，I01转为待B动态复验。首次完整性检查的源码变化记录保留，不把旧缺陷或历史失败直接当作新源码现状。23份历史输入原件与副本均一致；本轮未修改生产文件。

本轮唯一写入位置是本目录；生产源码、测试、A/B交付与历史档案只读。未启动服务或操作8097/8103/8104，未运行Lean，未调用千问，未读取密钥，未触及真实研究库，未安装框架，未对外发送。
