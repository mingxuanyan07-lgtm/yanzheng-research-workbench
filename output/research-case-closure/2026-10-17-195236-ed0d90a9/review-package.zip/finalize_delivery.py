"""Freeze this run's material manifest and portable review package. No app imports."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,obj):(R/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read(name):return json.loads((R/name).read_text(encoding='utf-8'))
if (R/'READY.json').exists():raise SystemExit('Refuse overwriting frozen READY; preserve unique run.')
v=read('validation.json')
if v['failed']:raise SystemExit('Blocking material validation failures remain')
T=datetime.now(timezone(timedelta(hours=8))).isoformat()
inputs={i['copy_path']:i for i in read('INPUT_MANIFEST.json')['files']}
controls={'ARTIFACT_MANIFEST.json','READY.json','review-package.zip','SHA256SUMS.txt','PACKAGE_CHECK.json'}
records=[]
for p in sorted(R.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(R).as_posix()
    if rel in controls:continue
    if rel in inputs:
        src=inputs[rel]
        role='historical_artifact_verbatim_copy'
        if p.name in ('historical-output.txt','raw-model-content.txt','model-payload.json'):role='historical_real_model_output_copy_not_new_success'
        elif p.name in ('historical-independent-review.json','feedback.json'):role='historical_assistant_review_not_independent_human'
        elif p.name in ('curated-proposal.json','notes-and-sources.json','claim-ledger.json'):role='historical_curated_example_not_model_success'
        origin={'kind':role,'source_path':src['source_path'],'source_sha256':src['sha256'],'captured_at':src['captured_at']}
    elif rel.startswith('sources/'):
        origin={'kind':'public_source_snapshot_or_extraction_or_http_facts','source_register':'sources/retrieval.json','reading_register':'SOURCE_VERIFICATION.json'}
    elif rel=='evidence/theory.py.snapshot.txt':
        origin={'kind':'read_only_production_text_snapshot','source_path':'D:/天猫AI/webapp/theory.py','observations':'CODE_OBSERVATIONS.json',
                'scope':'Snapshot is concurrent updated version; not initial version; no execution.'}
    elif rel.startswith('calculations/'):
        origin={'kind':'actual_finite_calculation_and_archival_checks','script':'offline_checks.py','scope':'Not universal proof certification'}
    elif rel in ('validation.json','SOURCE_DRIFT.json') or rel.startswith('validation/'):
        origin={'kind':'actual_validation_or_preserved_diagnostic','script':'validate_bundle.py','scope':'Structure/integrity; runtime and independent review not performed'}
    elif rel.startswith('review-package/'):
        origin={'kind':'assistant_prepared_independent_review_material_or_blank_form','sources':['CASE_SPEC.md','DERIVATION.md','claim-ledger.json'],
                'independent_human_review':'pending'}
    elif p.suffix=='.py':
        origin={'kind':'assistant_authored_local_standard_library_script','purpose':'Scoped material capture, record generation, finite check, validation or packaging; never application code'}
    else:
        origin={'kind':'assistant_authored_material_or_record','sources':['INPUT_MANIFEST.json','SOURCE_VERIFICATION.json','DERIVATION.md'],
                'detail':'Specific attribution and boundaries inside file; no independent human sign-off'}
    records.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'origin':origin})
put('ARTIFACT_MANIFEST.json',{'schema_version':'research-case-artifact-manifest-v1','created_at':T,
 'hash_algorithm':'SHA256','hash_scope':'Exact saved file bytes','files':records,
 'excluded_control_files':sorted(controls),'control_integrity':'READY hashes this manifest; SHA256SUMS hashes every file except itself after packaging.',
 'meaning':'Integrity and provenance labels, not mathematical certification.'})
ready={'schema_version':'research-case-closure-ready-v1','created_at':T,'run_directory':str(R),
 'case_id':'pointwise-limit-continuity-known-result','status':'ready_for_independent_review_not_finally_accepted',
 'case_spec':'CASE_SPEC.md','source_review':'SOURCE_VERIFICATION.json','claim_ledger':'claim-ledger.json',
 'proof_draft':'DERIVATION.md','model_comparison':'MODEL_COMPARISON.md','obligations':'OBLIGATIONS.json',
 'issues':'ISSUES.md','scenarios':'ACCEPTANCE_SCENARIOS.md','handoff':'HANDOFF.md',
 'independent_review_package':'review-package.zip','independent_review_entry':'review-package/README.md',
 'mathematics':{'kind':'known_result_verification_and_condition_analysis','original_P0':'false_x_power_n_counterexample',
 'revised_P1':'sufficient_uniform_convergence_continuity_proof_draft_complete',
 'condition_P2':'uniform_convergence_not_necessary_moving_hat_counterexample',
 'assistant_check':'complete','independent_mathematician_review':'pending','independent_reviewer':None,
 'application_obligations':'four_open_unchanged','formal_status':'not_formally_verified','final_case_acceptance':False},
 'historical_model_quality':{'version':'v1.4','all_three_raw_outputs':'rejected_as_returned','new_quality_improvement_evidence':False,
 'main_case_historical_call_id':'06c7c5d1b59d4e02906e1e58d7072ea2','main_case_historical_tokens':6236,
 'historical_total_tokens':23512,'current_real_model_calls':0},
 'validation':{'path':'validation.json','sha256':sha(R/'validation.json'),'status':v['status'],
               'passed':v['passed'],'warnings':v['warnings'],'blocking_failures':v['failed'],
               'finite_checks':35,'finite_check_failures':0,'finite_checks_are_universal_proofs':False,
               'input_originals_and_copies':23,'selected_production_files_monitored':11,
               'production_files_changed_concurrently':len(read('SOURCE_DRIFT.json')['changes']),
               'first_source_drift_failure_preserved':'validation/attempt-01.json'},
 'scope':{'writes_only_this_run_directory':True,'production_source_edits_by_this_task':0,'test_source_edits':0,'old_archive_edits':0,
          'website_started':False,'website_api_calls':0,'ports_8097_8103_8104_operated':False,'lean_runs':0,
          'real_research_database_access':False,'credential_access':False,'new_frameworks_installed':False,'messages_sent':0,
          'demo_video_or_promotional_material_created':False},
 'application_source_freeze':False,
 'source_drift_interpretation':'4 source files changed during work. New theory snapshot has candidate unified feedback filtering. No new runtime/browser validation; original defect is historical, not asserted still present.',
 'pending':['Independent mathematician review of four obligations, P2, sources and attribution',
            'B dynamic verification of candidate feedback-context change and whole browser exports/frontend contract',
            'B assessment of per-claim/per-obligation evidence association and original source version fingerprints',
            'A runtime reliability work; formal semantics review only if subsequently authorized',
            'Final integrated acceptance by supervisor'],
 'manifest':{'path':'ARTIFACT_MANIFEST.json','sha256':sha(R/'ARTIFACT_MANIFEST.json'),'file_count':len(records)},
 'control_hashes':'SHA256SUMS.txt (excludes itself only); packaging facts in PACKAGE_CHECK.json',
 'authority':'Prepared by assistant; no independent expert certification, no application-state mutation.'}
put('READY.json',ready)
members=[R/e['path'] for e in records]+[R/'ARTIFACT_MANIFEST.json',R/'READY.json']
with zipfile.ZipFile(R/'review-package.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in members:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(R/'review-package.zip') as z:
    crc_bad=z.testzip();names=set(z.namelist());expected={p.relative_to(R).as_posix() for p in members}
    mismatches=[name for name in names if hashlib.sha256(z.read(name)).hexdigest()!=sha(R/name)]
package_check={'checked_at':T,'origin':'actual_local_zip_member_and_byte_verification','script':'finalize_delivery.py',
 'script_sha256':sha(Path(__file__)),'archive':'review-package.zip','archive_sha256':sha(R/'review-package.zip'),
 'archive_bytes':(R/'review-package.zip').stat().st_size,'member_count':len(names),'expected_count':len(expected),
 'membership_exact':names==expected,'crc_bad_member':crc_bad,'byte_mismatches':mismatches,
 'passed':names==expected and not crc_bad and not mismatches,
 'excluded_from_archive':['review-package.zip','PACKAGE_CHECK.json','SHA256SUMS.txt'],
 'meaning':'Package integrity only; independent review remains pending.'}
put('PACKAGE_CHECK.json',package_check)
if not package_check['passed']:raise SystemExit('ZIP verification failed')
sums=[]
for p in sorted(R.rglob('*')):
    if p.is_file() and p.name!='SHA256SUMS.txt':sums.append(f"{sha(p)}  {p.relative_to(R).as_posix()}")
(R/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
for line in (R/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    digest,rel=line.split('  ',1)
    if sha(R/rel)!=digest:raise SystemExit('Post-package checksum mismatch: '+rel)
print(json.dumps({'status':ready['status'],'artifact_files':len(records),'zip_members':len(names),
 'zip_bytes':package_check['archive_bytes'],'checksum_entries':len(sums),'sha256sums_sha256':sha(R/'SHA256SUMS.txt'),
 'ready_sha256':sha(R/'READY.json'),'package_check_passed':package_check['passed']},ensure_ascii=False,indent=2))
