# 理论失败审阅 API 合同 v1

新增字段兼容旧项目，旧接口与空 `{}` propose 请求继续可用。不存在浏览器上传原模型内容的接口。

- 服务端在 JSON/结构校验之前捕获 `choices[0].message.content`；最多保存 50000 字符。完整内容计算 SHA256；截断、缺失、服务响应前缀与模型正文明确区分。HTTP 响应最多读取 256 KiB；超限仅保存已读取前缀，完整体哈希未知。实际凭据若被回显会替换，记录 redacted，不能称逐字原件。公共模型状态不包含正文。SHA256针对所标识的UTF-8文本而非HTTP线缆字节；非JSON响应体以UTF-8替换解码，`text_representation` 明示，不冒称保留任意二进制原件。
- `theory.failure_records[]`：不可接受的独立材料。关联 project_id、source_call_id、request_id、usage（未知保留 null）、prompt_version、原卡版本/哈希/快照、输入 messages/哈希、上下文指纹、capture、diagnostic、category、source、reviews。结构失败、服务失败、上下文冲突不是人工数学结论。所有人工意见均 unverified_feedback。
- `GET /api/projects/{id}/theory/failures/{failure_id}` 读取完整材料；同路径 `/export` 下载 JSON。本项目不存在返回 404，不能跨项目寻址。
- `POST .../failures/{failure_id}/reviews` 仅接收 `{reason, expected_revision, request_id}`。reason 为非空最多2000字；revision为非负整数；request_id为1–80字符幂等标识。相同标识同内容重复提交返回原状态，不增加版本；不同内容或版本冲突409。不能提交 capture、payload、source 或数学已证明状态。
- `GET .../theory/next-context` 只读完整下一轮 messages、context_token、纳入/排除记录、字符预算。只带最近两条适用审阅（含旧提议反馈），原卡及基础上下文须匹配；过期材料保留但不自动发送；无反馈、缺正文、截断的失败材料排除。超50000字符明确 blocked，不删减原错误步骤。预览不保存卡、不发送请求。
- `POST .../theory/propose` 新增可选 `{context_token}`，校验预览指纹，过期返回409且不调用模型。网页先要求保存草稿再预览；研究者再明确点击生成。旧客户端 `{}` 继续按服务端当前上下文生成。无自动重试。
- 理论整体 JSON/Markdown 导出包含失败材料与审阅。失败不能调用提议接受路由。`historical_replay` 为服务器测试夹具标记，仅离线历史回放注入；`curated_example` 无真实调用ID，二者不能声称新千问调用或纠错成功。

限制：本地单用户，无跨用户授权承诺；读权限仍按项目路由隔离。服务结果持久化成功前不宣称归档成功。未完成响应/进程中止不保证能取得正文或实际用量。旧归档 helper 保留兼容，不暴露为上传接口。
