# 逐条论断账本

身份：助手核查。机器原件为 claim-ledger.json；每项依据含具体位置与文件 SHA256；本文件哈希见 ARTIFACT_MANIFEST。独立审阅统一 pending。

## C01 · P0

每个正整数n，x^n在[0,1]上相对连续。

- 推导：因式分解得|x^n-a^n|≤n|x-a|；δ=η/n。
- 反例/边界检查：检查n=1与a=0,1；δ依赖n合法。
- 条件：n≥1；a,x∈[0,1]；η>0
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：pointwise_limit
- 依据：`DERIVATION.md`；位置：D1；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/UW521.html`；位置：x^n example; text15–20；边界：来源反例背景；具体n-Lipschitz估计由助手给出。；SHA256 `493d7663bab8fea176680b34a9a132309fd69d85ccd0822b39067bc0a2eda669`

## C02 · P0

点态极限是x<1时0、x=1时1。

- 推导：端点直接；0<x<1令t=1/x-1，Bernoulli和N>1/(tε)给全尾误差。
- 反例/边界检查：不能把N(x,ε)当全域共同N。
- 条件：∀x∈D ∀ε>0 ∃N≥1 ∀n≥N
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C01；原义务：pointwise_limit
- 依据：`DERIVATION.md`；位置：D2；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/UW521.html`；位置：x^n example; text15–20；边界：直接记载分段极限；显式N为助手展开。；SHA256 `493d7663bab8fea176680b34a9a132309fd69d85ccd0822b39067bc0a2eda669`

## C03 · P0

f在1不连续，x=1-min(δ/2,1/2)对全δ合法。

- 推导：ε₀=1/2；0<t≤1/2且t≤δ/2<δ；x∈[1/2,1)，函数差1。
- 反例/边界检查：旧x=1-δ/2在δ=4时出域；不借右侧函数值。
- 条件：∀δ>0；相对域D
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C02；原义务：witness_domain
- 依据：`DERIVATION.md`；位置：D3；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`evidence/inputs/output/theory-review-integration/public-case/curated-proposal.json`；位置：proof_routes[1].steps[1]；边界：历史人工精确见证，待本轮推导核查。；SHA256 `a8168b83cdb55327ba7dde679132873c632f84c8cafbe10195b052e7ac08b218`

## C04 · P0

P0普遍命题为假。

- 推导：同一列满足每项连续与逐点收敛而极限不连续。
- 反例/边界检查：反例覆盖全部前提，不能只说经典反例。
- 条件：P0的域、值域、n量词完全不变
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C01, C02, C03；原义务：pointwise_limit, witness_domain
- 依据：`DERIVATION.md`；位置：D1–D3；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`

## C05 · P0

x^n到该分段极限不一致收敛。

- 推导：ε₀=1/2；给N取n=N,x=1-1/(4n)；Bernoulli下界3/4。
- 反例/边界检查：峰值靠端点，固定网格不能证明或排除。
- 条件：∀N≥1 ∃n≥N ∃x∈D
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C02；原义务：不新增义务
- 依据：`DERIVATION.md`；位置：D4；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/UW521.html`；位置：nonuniformity; text59–80；边界：来源用根式见证；本稿有理见证不是摘录。；SHA256 `493d7663bab8fea176680b34a9a132309fd69d85ccd0822b39067bc0a2eda669`

## C06 · P1

一致收敛量词中N不依赖自变量。

- 推导：∀ε>0 ∃N ∀n≥N ∀y∈D。
- 反例/边界检查：交换∀y与∃N得到点态收敛，C01–C05说明不够。
- 条件：同一个域D，同一极限函数
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：uniform_quantifiers
- 依据：`DERIVATION.md`；位置：D0,D5.1；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/UW521.html`；位置：Uniform convergence definition; text54–58；边界：直接支持定义。；SHA256 `493d7663bab8fea176680b34a9a132309fd69d85ccd0822b39067bc0a2eda669`

## C07 · P1

同一个f_N同时控制x和a两个逼近误差。

- 推导：对ε/3选统一N再特取n=N；分别代y=x和y=a。
- 反例/边界检查：不得用N(x)和N(a)却不解释统一选择；无需先知道x。
- 条件：一致收敛；x,a∈D
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C06；原义务：uniform_quantifiers
- 依据：`DERIVATION.md`；位置：D5.1；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/LEBL62.html`；位置：Theorem6.2.2 proof; text490–494；边界：来源函数指标名k；本稿名N。；SHA256 `de82ca50522437fe77ae8ce2ab84b001c79d119e54872303a76d2d4aba6fc73c`

## C08 · P1

固定f_N后由其在a的相对连续性选δ。

- 推导：容差ε/3；δ依赖a、ε、固定N，随后对全部邻域内x有效。
- 反例/边界检查：不要求δ对所有n有效；两端点只取域内x。
- 条件：每项相对连续；N已经固定
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C07；原义务：relative_continuity
- 依据：`DERIVATION.md`；位置：D5.2；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/LEBL62.html`；位置：Theorem6.2.2 and proof; text483–516；边界：原文序列连续性；ε–δ展开属本稿。；SHA256 `de82ca50522437fe77ae8ce2ab84b001c79d119e54872303a76d2d4aba6fc73c`

## C09 · P1

三角不等式给|f(x)-f(a)|<ε。

- 推导：两个统一逼近误差加固定函数连续性误差，三项各<ε/3。
- 反例/边界检查：没有把≤ε误当<ε；直接用逐点共同界避开严格sup陷阱。
- 条件：|x-a|<δ且x∈D
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C07, C08；原义务：relative_continuity
- 依据：`DERIVATION.md`；位置：D5.3；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`

## C10 · P1

一致收敛保持连续性是充分修订；此推导不需紧致性。

- 推导：a与ε任意，连续性定义成立；逐步未使用有限覆盖。
- 反例/边界检查：不能将“P1真”标为“P0真”；不反推必要性。
- 条件：每项连续+同域一致收敛
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C09；原义务：relative_continuity
- 依据：`DERIVATION.md`；位置：D5；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/UW521.html`；位置：first continuity theorem; text150–154；边界：一般度量定义域陈述，不要求紧致。；SHA256 `493d7663bab8fea176680b34a9a132309fd69d85ccd0822b39067bc0a2eda669`
- 依据：`sources/LEBL62.html`；位置：Theorem6.2.2; text483–484；边界：任意实数子集陈述。；SHA256 `de82ca50522437fe77ae8ce2ab84b001c79d119e54872303a76d2d4aba6fc73c`

## C11 · P2

h_n=max(0,1-|2nx-1|)每项在D连续。

- 推导：分段接点一致或2n-Lipschitz。
- 反例/边界检查：x=0、1/(2n)、1/n、1全包含；n=1合法。
- 条件：n≥1，D=[0,1]
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`DERIVATION.md`；位置：D6；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`evidence/inputs/output/theory-quality-next/offline/math-reference-review.md`；位置：missing-condition辅助例；边界：历史助手例子；本轮展开，不是模型给出。；SHA256 `fef6d37acff5cc4a3bf8f0000618043c3c882595830c92acad0aecb4c9e93889`

## C12 · P2

h_n在D上逐点至恒零连续函数。

- 推导：x=0恒零；x>0取N>1/x，尾项全零。
- 反例/边界检查：移动点x_n不固定，不能用其值1否定点态收敛。
- 条件：先固定x；N可依赖x
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C11；原义务：不新增义务
- 依据：`DERIVATION.md`；位置：D6；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`

## C13 · P2

h_n不一致收敛；因此一致收敛非必要。

- 推导：给N取n=N，x_n=1/(2n)，误差1；与C11–C12合并。
- 反例/边界检查：ε₀=1/2固定，所有N均有峰顶。
- 条件：与P1相同定义域及连续函数列
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：C11, C12；原义务：不新增义务
- 依据：`DERIVATION.md`；位置：D6；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`sources/LEBL62.html`；位置：Exercise6.2.5 and note; text870–874；边界：只有任务题面；不作为此精确构造已证依据。；SHA256 `de82ca50522437fe77ae8ce2ab84b001c79d119e54872303a76d2d4aba6fc73c`

## C14 · P2

x/n在D上一致至零，不能作为非一致反例。

- 推导：全域误差≤1/n且x=1达到；取N>1/ε。
- 反例/边界检查：不是将x/n改完后记作旧模型正确。
- 条件：D=[0,1]，n≥1
- 核查状态：assistant_checked_proof_draft_complete；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`DERIVATION.md`；位置：D6；边界：本轮助手推导；非原模型输出、非独立人工或形式核验。；SHA256 `0601350ffb7e37b0363ba63767c37bea4830ed283cf5ff6fe50d6ed2f397ade8`
- 依据：`evidence/inputs/output/theory-review-integration/public-case/original-context.json`；位置：theory.proposals[0].submitted_payload.search_leads[0]；边界：记录错误候选的原位置，不给数学背书。；SHA256 `b9fef8c1a7814fe58deb87a0eafa79583a202aa913d20500325269f2e04753fb`

## C15 · H14

原唯一反例笔记不足以归因修补定理。

- 推导：逐字对比笔记内容与claim；同URL其他段落并未进入该笔记。
- 反例/边界检查：background标签与后来新读正文均不能追溯扩大原范围。
- 条件：仅谈历史输入支持范围，不否认P1真
- 核查状态：assistant_checked_evidence_scope_failure；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`evidence/inputs/output/theory-quality-next/inputs/missing-condition/messages.json`；位置：user.evidence_notes[0] / review_feedback[0]；边界：实际冻结输入，用户内容在引导句后。；SHA256 `9f71d460faf6069014639dbb00033cb371785ab4772c8b73082e0bbe0065039d`
- 依据：`evidence/inputs/output/theory-review-integration/public-case/historical-output.txt`；位置：proof_routes[0].evidence[0].claim；边界：原始越界语句。；SHA256 `dabf301675fa6a589e0f6ccf801c8f0ca2f338573d0707633c522087b01bb923`

## C16 · H14

超长义务ID有49字符，原结构拒绝应保留。

- 推导：标准库len和ASCII合同检查，原字节不变。
- 反例/边界检查：结构错误不推出数学命题为假。
- 条件：原v1.4输出
- 核查状态：assistant_checked_archival_fact；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`evidence/inputs/output/theory-review-integration/public-case/historical-output.txt`；位置：proof_routes[2].obligations[0].id；边界：原字符串。；SHA256 `dabf301675fa6a589e0f6ccf801c8f0ca2f338573d0707633c522087b01bb923`
- 依据：`evidence/inputs/output/theory-quality-next/inputs/missing-condition/messages.json`；位置：system ID max40 contract；边界：历史合同。；SHA256 `9f71d460faf6069014639dbb00033cb371785ab4772c8b73082e0bbe0065039d`

## C17 · HISTORICAL

v1.4三份原样输出均整体拒绝；本轮无新模型改善证据。

- 推导：保留历史状态；本轮禁止新增请求。
- 反例/边界检查：主案正确片段/人工稿不计为模型整体成功。
- 条件：历史三案结论与本轮执行事实分开
- 核查状态：historical_report_checked；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`evidence/inputs/output/theory-quality-next/validation.json`；位置：overall_status / cases[*].overall_usable_as_returned；边界：历史报告，不是本轮重试或重评全部三案。；SHA256 `b30fb61c3000ef49d0b8eb4c6ac8f1d2f2edde92c156cc1939319a00db4a9f4e`

## C18 · REVIEW_STATUS

四应用义务仍open；独立审阅pending；无形式证明。

- 推导：本轮只交外部材料，不写应用状态。
- 反例/边界检查：助手自查、有限计算和旧independent文件名均不构成人工专家认证。
- 条件：本轮及已提供历史材料
- 核查状态：status_boundary_preserved；未决：独立数学工作者尚未审阅本条的推理、范围与归因。
- 依赖：无；原义务：不新增义务
- 依据：`evidence/inputs/output/theory-review-integration/public-case/README.md`；位置：人工版与四项义务说明；边界：历史应用状态依据，非当前DB读取。；SHA256 `bb3d1ffb1e2beca3726014582e7d3c40fa9cff4583fd392b8d6785a2349d1e0b`
- 依据：`evidence/inputs/output/theory-review-integration/public-case/claim-ledger.json`；位置：independent_mathematician_review；边界：旧助手记录仍待真人。；SHA256 `25e0e6239f50ae3d923aa86e2901b9f2991d6f67824668bcb567efbba28c4537`
