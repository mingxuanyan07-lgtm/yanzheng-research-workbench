# 四项义务核查表

来源：历史 CUR 的义务 ID、CASE_SPEC、DERIVATION 与逐论断账本。输入/产物 SHA256 见 INPUT_MANIFEST / ARTIFACT_MANIFEST；机器记录见 OBLIGATIONS.json。所有结论为本轮助手自查。

| 应用原义务 ID / 依赖 | 检查材料与关键检查 | 本轮结论依据 | 对外状态 |
|---|---|---|---|
| pointwise_limit / 无 | D1 的 n-Lipschitz 界；D2 分 x=0、0<x<1、x=1；C01–C02 | 每项全域相对连续；归纳与阿基米德选择给每个固定 x 的 N(x,ε) | 证明稿完成；助手核查完成；独立审阅 pending；应用 open |
| witness_domain / pointwise_limit | D3；C03–C04；负向样例 δ=4 的旧非法见证 | ε₀先固定；每个δ有0<t≤1/2和t<δ；x∈D且函数差1 | 证明稿完成；助手核查完成；独立审阅 pending；应用 open |
| uniform_quantifiers / 无 | D0、D5.1；C06–C07；与D2、D4比较 | `∀ε ∃N ∀n≥N ∀x`；特取n=N；同一个N同时用于x和a | 证明稿完成；助手核查完成；独立审阅 pending；应用 open |
| relative_continuity / uniform_quantifiers | D5.2–D5.3；C08–C10；LEBL62 定理6.2.2证明对照 | 固定f_N后选δ；x限制在D；三项严格小于ε/3；两端点有效 | 证明稿完成；助手核查完成；独立审阅 pending；应用 open |

上表是**外部研究材料核查记录**，不写入应用、不改变旧义务、卡、数据库或形式状态。`not_formally_verified` 保持。独立审阅人、日期、签署结论均为空；待审表不预填“通过”。

P2 的必要性检查见 D6/C11–C14，是本轮条件边界材料，不新增或替换原四义务。独立数学工作者应同时检查该例，避免把“一致充分”误当“一致必要”。

本轮没有发现当前主稿尚缺的证明步骤；这一判断来自助手，仍可被独立审阅纠正。有限有理计算只辅助检查边界和文件事实，不计作任何普遍义务的证明。最终验收由总验收结合独立审阅与实际工程证据判断。
